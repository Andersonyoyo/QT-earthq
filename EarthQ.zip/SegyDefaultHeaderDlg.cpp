// SegyDefaultHeaderDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "SegyDefaultHeaderDlg.h"
#include "afxdialogex.h"
#include "resource.h"

// CSegyDefaultHeaderDlg �Ի���

IMPLEMENT_DYNAMIC(CSegyDefaultHeaderDlg, CDialogEx)

CSegyDefaultHeaderDlg::CSegyDefaultHeaderDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSegyDefaultHeaderDlg::IDD, pParent)
{

}

CSegyDefaultHeaderDlg::~CSegyDefaultHeaderDlg()
{
}

void CSegyDefaultHeaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SAMPLECODE_COMBO, m_sampleCode);
	DDX_Control(pDX, IDC_GAINTYPE_COMBO, m_gainType);
	DDX_Control(pDX, IDC_GAINTYPE_COMBO2, m_traceSort);
}


BEGIN_MESSAGE_MAP(CSegyDefaultHeaderDlg, CDialogEx)
	ON_BN_CLICKED(IDC_APPLY1, &CSegyDefaultHeaderDlg::OnBnClickedApply1)
END_MESSAGE_MAP()


// CSegyDefaultHeaderDlg ��Ϣ��������


BOOL CSegyDefaultHeaderDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_sampleCode.AddString(_T("FLOATING PT"));
	m_sampleCode.AddString(_T("FIXED PT"));
	m_sampleCode.AddString(_T("FIXED PT-GAIN"));
	m_sampleCode.AddString(_T("CORRELATED"));
	m_sampleCode.SetCurSel(0);

	m_gainType.AddString(_T("FIXED"));
	m_gainType.AddString(_T("BINARY"));
	m_gainType.AddString(_T("FLOATING POINT"));
	m_gainType.AddString(_T("OTHER"));
	m_gainType.SetCurSel(0);

	m_traceSort.AddString(_T("RECORD"));
	m_traceSort.AddString(_T("CDP"));
	m_traceSort.AddString(_T("OTHER"));
	m_traceSort.SetCurSel(0);


	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CSegyDefaultHeaderDlg::ShowMyDialog(CMainFrame *pFather)
{
	pFatehrFrame = pFather;
	DoModal();
}

void CSegyDefaultHeaderDlg::OnBnClickedApply1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);

	CWnd *pWnd = GetDlgItem(IDC_APPLY1);
	pWnd->EnableWindow(FALSE);
}
