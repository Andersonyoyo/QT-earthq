
#pragma once
#include "DeviceDescribe.h"
#include "ViewTree.h"
#include "DrawDataDlg.h"

class CGroupViewToolBar : public CMFCToolBar
{
	virtual void OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL bDisableIfNoHndler)
	{
		CMFCToolBar::OnUpdateCmdUI((CFrameWnd*) GetOwner(), bDisableIfNoHndler);
	}

	virtual BOOL AllowShowOnList() const { return FALSE; }
};

class CGroupView : public CDockablePane
{
	DECLARE_DYNAMIC(CGroupView)
// ����
public:
	CGroupView();

	void AdjustLayout();
	void OnChangeVisualStyle();

// ����
protected:

	CViewTree m_wndGroupView;
	CImageList m_GroupViewImages;
	CGroupViewToolBar m_wndToolBar;
	HTREEITEM hRoot;/*���ڵ�*/

public:
	CDrawDataDlg drawDlg;

protected:
	void InitGroupView();
	BOOL CGroupView::AddOneDev2Tree(DEVICE *dev);
public:
	BOOL UpdateGroupDev(UINT dev_num,DEVICE *dev/*�������ݱ��棿��*/);//������ͼ���и���
	void SwitchProp();//�ػ��Ӧ���������
	void GetDataDlgOutput();//��������
	//�ڵ�����
	void treeSort();

// ʵ��
public:
	virtual ~CGroupView();

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnToolBarButton();
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnMenuSelect(UINT nID);
	DECLARE_MESSAGE_MAP()
};

