#pragma once
#include "DrawDataDlg.h"

// CADWave

class CADWave : public CDockablePane
{
	DECLARE_DYNAMIC(CADWave)

public:
	CADWave();
	virtual ~CADWave();

public:
	CDrawDataDlg drawWave;

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


