#pragma once
#include "ProcessDlg.h"

// CProcessBar

class CProcessBar : public CDockablePane
{
	DECLARE_DYNAMIC(CProcessBar)

public:
	CProcessBar();
	virtual ~CProcessBar();

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);

public:
	
	afx_msg void OnDestroy();

public:
	CProcessDlg m_processDlg;
};


