#pragma once


// CDetailView ��ͼ

class CDetailView : public CView
{
	DECLARE_DYNCREATE(CDetailView)

public:
	CDetailView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CDetailView();
	CEarthQDoc* GetDocument() const;
public:
	virtual void OnFinalRelease();
	virtual void OnDraw(CDC* pDC);      // ��д�Ի��Ƹ���ͼ
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
protected:
	CListCtrl m_tab;
	void InitListTable();
protected:
	DECLARE_MESSAGE_MAP()
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};
#ifndef _DEBUG  // LayoutView.cpp �еĵ��԰汾
inline CEarthQDoc* CDetailView::GetDocument() const
{ return reinterpret_cast<CEarthQDoc*>(m_pDocument); }
#endif

