#pragma once


// MyMFCToolBar

class MyMFCToolBar : public CMFCToolBar
{
	DECLARE_DYNAMIC(MyMFCToolBar)

public:
	MyMFCToolBar();
	virtual ~MyMFCToolBar();

protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL CanBeClosed() const;  
};


