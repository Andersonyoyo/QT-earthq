#pragma once
#include "MapView.h"

// MapConfigure �Ի���

class MapConfigure : public CDialogEx
{
	DECLARE_DYNAMIC(MapConfigure)

public:
	MapConfigure(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~MapConfigure();

// �Ի�������
	enum { IDD = IDD_MAP_CONFIGURE };
protected:
	MapView *pFatherView;
public:
	void ShowMyDialog(MapView *pView);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedCancel();
};
