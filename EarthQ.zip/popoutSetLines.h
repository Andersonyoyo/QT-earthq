#pragma once
#include "DeviceDescribe.h"
#include "EarthQDoc.h"
#include<vector>


using namespace std;

// popoutSetLines �Ի���
class CMainFrame;
class popoutSetLines : public CDialog
{
	DECLARE_DYNAMIC(popoutSetLines)

public:
	popoutSetLines(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~popoutSetLines();

protected:
	CMainFrame *pFatehrFrame;

// �Ի�������
	enum { IDD = IDD_POPOUT_NEWSETLINE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangePopoutSetline();
	afx_msg void OnBnClickedSetlineOk();

public:
	void ShowMyDialog(CMainFrame *pFather);
	void getLineGrad(float gradTrans,double *X,double *Y);
	void setLineATrace();
	CEarthQDoc *GetDocPtr(void);
	float* bubbleSort(float arr[], int n);

public:
	double gradGet;
	double *axisX;
	double *axisY;
	int m_lineNo;
	int lineGet;
	
	int inLineDev_num;
	vector<double> inLine; 


private:
	DEVICE *dev;
	int m_devNum;
};
