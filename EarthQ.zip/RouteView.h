
#pragma once
#include "DeviceDescribe.h"
#include "ViewTree.h"

class CClassToolBar : public CMFCToolBar
{
	virtual void OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL bDisableIfNoHndler)
	{
		CMFCToolBar::OnUpdateCmdUI((CFrameWnd*) GetOwner(), bDisableIfNoHndler);
	}

	virtual BOOL AllowShowOnList() const { return FALSE; }
};

class CRouteView : public CDockablePane
{
	DECLARE_DYNAMIC(CRouteView)
public:
	CRouteView();
	virtual ~CRouteView();

	void AdjustLayout();
	void OnChangeVisualStyle();

protected:
	CClassToolBar m_wndToolBar;
	CViewTree m_wndRouteView;
	CImageList m_RouteViewImages;
	UINT m_nCurrSort;
	HTREEITEM hRoot;/*���ڵ�*/
	void InitRouteView();
public:
	BOOL UpdateRouteDev(UINT dev_num,DEVICE *dev);
	void SwitchProp();
// ��д
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);//�ļ��������豸������ݷ���DEVICE�У����ء�Mac�����������Ҫ��device������(Group���Ƿ���Ҫ����)
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnMenuSelect(UINT nID);
	afx_msg void OnToorBarButton();
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg LRESULT OnChangeActiveTab(WPARAM, LPARAM);
	afx_msg void OnSort(UINT id);
	afx_msg void OnUpdateSort(CCmdUI* pCmdUI);

	DECLARE_MESSAGE_MAP()
};

