
#include "stdafx.h"
#include "MainFrm.h"
#include "RouteView.h"
#include "Resource.h"
#include "EarthQ.h"
#include "EarthQDoc.h"
class CRouteViewMenuButton : public CMFCToolBarMenuButton
{
	friend class CRouteView;

	DECLARE_SERIAL(CRouteViewMenuButton)

public:
	CRouteViewMenuButton(HMENU hMenu = NULL) : CMFCToolBarMenuButton((UINT)-1, hMenu, -1)
	{
	}

	virtual void OnDraw(CDC* pDC, const CRect& rect, CMFCToolBarImages* pImages, BOOL bHorz = TRUE,
		BOOL bCustomizeMode = FALSE, BOOL bHighlight = FALSE, BOOL bDrawBorder = TRUE, BOOL bGrayDisabledButtons = TRUE)
	{
		pImages = CMFCToolBar::GetImages();

		CAfxDrawState ds;
		pImages->PrepareDrawImage(ds);

		CMFCToolBarMenuButton::OnDraw(pDC, rect, pImages, bHorz, bCustomizeMode, bHighlight, bDrawBorder, bGrayDisabledButtons);

		pImages->EndDrawImage(ds);
	}
};

IMPLEMENT_SERIAL(CRouteViewMenuButton, CMFCToolBarMenuButton, 1)

//////////////////////////////////////////////////////////////////////
// ����/����
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CRouteView,CDockablePane)
CRouteView::CRouteView()
{
	m_nCurrSort = ID_SORTING_GROUPBYTYPE;
}

CRouteView::~CRouteView()
{
}

BEGIN_MESSAGE_MAP(CRouteView, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND_RANGE(ID_RMENU_A, ID_RMENU_D, OnMenuSelect)
	ON_COMMAND(ID_NEW_FOLDER, OnToorBarButton)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_COMMAND_RANGE(ID_SORTING_GROUPBYTYPE, ID_SORTING_SORTBYACCESS, OnSort)
	ON_UPDATE_COMMAND_UI_RANGE(ID_SORTING_GROUPBYTYPE, ID_SORTING_SORTBYACCESS, OnUpdateSort)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRouteView ��Ϣ��������

int CRouteView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// ������ͼ:
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

	if (!m_wndRouteView.Create(dwViewStyle, rectDummy, this, 2))
	{
		TRACE0("δ�ܴ���·��\n");
		return -1;      // δ�ܴ���
	}

	// ����ͼ��:
	m_wndToolBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_SORT);
	m_wndToolBar.LoadToolBar(IDR_SORT, 0, 0, TRUE /* ������*/);

	OnChangeVisualStyle();

	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() & ~(CBRS_GRIPPER | CBRS_SIZE_DYNAMIC | CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT));

	m_wndToolBar.SetOwner(this);

	// �������ͨ���˿ؼ�·-�ɣ�������ͨ�������·-��:
	m_wndToolBar.SetRouteCommandsViaFrame(FALSE);
	
	CMenu menuSort;
	menuSort.LoadMenu(IDR_POPUP_SORT);

	m_wndToolBar.ReplaceButton(ID_SORT_MENU, CRouteViewMenuButton(menuSort.GetSubMenu(0)->GetSafeHmenu()));

	CRouteViewMenuButton* pButton =  DYNAMIC_DOWNCAST(CRouteViewMenuButton, m_wndToolBar.GetButton(0));

	if (pButton != NULL)
	{
		pButton->m_bText = FALSE;
		pButton->m_bImage = TRUE;
		pButton->SetImage(GetCmdMgr()->GetCmdImage(m_nCurrSort));
		pButton->SetMessageWnd(this);
	}
	
	// ����һЩ��̬����ͼ����(�˴�ֻ������������룬�����Ǹ��ӵ�����)
	InitRouteView();

	return 0;
}

void CRouteView::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CRouteView::InitRouteView()
{
	hRoot = m_wndRouteView.InsertItem(_T("·�ɹ�ϵ"), 0, 0);
	m_wndRouteView.SetItemState(hRoot, TVIS_BOLD, TVIS_BOLD);
	m_wndRouteView.SetItemData(hRoot,0xFFFFFFFF);
	
}
typedef struct{//������
	HTREEITEM node;
	UINT ID;
}PARENT_DES;
/*�������豸�������豸��ɾ���豸����ͬһ�������ӿ���*/
BOOL CRouteView::UpdateRouteDev(UINT dev_num,DEVICE *dev)//�������ڵ�
{
	/*�޸ĺ���*/
	//m_wndRouteView.InsertItem(_T("��·��XX"), 1, 1, hRoot);
	HTREEITEM nodeHD;
	UINT i,k,pCount=0;
	CString str;
	m_wndRouteView.DeleteAllItems();
	InitRouteView();
	if(dev_num==0)
	{
		return TRUE;
	}
	/*����������ȫ�����ڵ�*/
	PARENT_DES parent[MAX_DEVICE_NUM];
	i=0;
	pCount=0;
	parent[pCount].ID=dev[i].routeID;
	str.Format(_T("·��%02d"),parent[pCount].ID);
	parent[pCount].node= m_wndRouteView.InsertItem(str, 0, 0, hRoot);
	m_wndRouteView.SetItemData(parent[pCount].node,parent[pCount].ID);/*������Ը�Ϊ�����豸��� �������*/
	str.Format(_T("%06d"),dev[i].devID);//����������ӵ����ڵ��ֵ�����ͣ�ѭ���л�����
	nodeHD=m_wndRouteView.InsertItem(str, 1, 1, parent[pCount].node);
	m_wndRouteView.SetItemData(nodeHD,dev[i].devID);/*������Ը�Ϊ�����豸��� �������*/
	m_wndRouteView.Expand(parent[pCount].node, TVE_EXPAND);
	pCount++;
	m_wndRouteView.Expand(hRoot, TVE_EXPAND);
	for(i=1;i<dev_num;i++)
	{
		for(k=0;k<pCount;k++)
		{
			if(dev[i].routeID==parent[k].ID)
			{
				str.Format(_T("%06d"),dev[i].devID);
				nodeHD=m_wndRouteView.InsertItem(str, 1, 1, parent[k].node);
				m_wndRouteView.SetItemData(nodeHD,dev[i].devID);/*������Ը�Ϊ�����豸��� �������*/
				break;
			}
		}
		if(k==pCount)/*û�ҵ�����Ҫ�½�*/
		{
			parent[pCount].ID = dev[i].routeID;
			str.Format(_T("·��%02d"),parent[pCount].ID);
			parent[pCount].node= m_wndRouteView.InsertItem(str, 0, 0, hRoot);
			m_wndRouteView.SetItemData(parent[pCount].node,parent[pCount].ID);/*������Ը�Ϊ�����豸��� �������*/
			str.Format(_T("%06d"),dev[i].devID);
			nodeHD=m_wndRouteView.InsertItem(str, 1, 1, parent[pCount].node);
			m_wndRouteView.SetItemData(nodeHD,dev[i].devID);/*������Ը�Ϊ�����豸��� �������*/
			/*չ��*/
			m_wndRouteView.Expand(parent[pCount].node, TVE_EXPAND);
			pCount++;
		}
	}
	return TRUE;
}

void CRouteView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CTreeCtrl* pWndTree = (CTreeCtrl*)&m_wndRouteView;
	ASSERT_VALID(pWndTree);

	if (pWnd != pWndTree)
	{
		CDockablePane::OnContextMenu(pWnd, point);
		return;
	}

	if (point != CPoint(-1, -1))
	{
		// ѡ���ѵ�������:
		CPoint ptTree = point;
		pWndTree->ScreenToClient(&ptTree);

		UINT flags = 0;
		HTREEITEM hTreeItem = pWndTree->HitTest(ptTree, &flags);
		if (hTreeItem != NULL)
		{
			pWndTree->SelectItem(hTreeItem);
		}
	}

	pWndTree->SetFocus();
	CMenu menu;
	menu.LoadMenu(IDR_POPUP_SORT);

	CMenu* pSumMenu = menu.GetSubMenu(0);

	if (AfxGetMainWnd()->IsKindOf(RUNTIME_CLASS(CMDIFrameWndEx)))
	{
		CMFCPopupMenu* pPopupMenu = new CMFCPopupMenu;

		if (!pPopupMenu->Create(this, point.x, point.y, (HMENU)pSumMenu->m_hMenu, FALSE, TRUE))
			return;

		((CMDIFrameWndEx*)AfxGetMainWnd())->OnShowPopupMenu(pPopupMenu);
		UpdateDialogControls(this, FALSE);
	}
}

void CRouteView::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient;
	GetClientRect(rectClient);

	int cyTlb = m_wndToolBar.CalcFixedLayout(FALSE, TRUE).cy;

	m_wndToolBar.SetWindowPos(NULL, rectClient.left, rectClient.top, rectClient.Width(), cyTlb, SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndRouteView.SetWindowPos(NULL, rectClient.left + 1, rectClient.top + cyTlb + 1, rectClient.Width() - 2, rectClient.Height() - cyTlb - 2, SWP_NOACTIVATE | SWP_NOZORDER);
}

BOOL CRouteView::PreTranslateMessage(MSG* pMsg)
{
	return CDockablePane::PreTranslateMessage(pMsg);
}

void CRouteView::OnSort(UINT id)
{
	if (m_nCurrSort == id)
	{
		return;
	}

	m_nCurrSort = id;

	CRouteViewMenuButton* pButton =  DYNAMIC_DOWNCAST(CRouteViewMenuButton, m_wndToolBar.GetButton(0));

	if (pButton != NULL)
	{
		pButton->SetImage(GetCmdMgr()->GetCmdImage(id));
		m_wndToolBar.Invalidate();
		m_wndToolBar.UpdateWindow();
	}
}

void CRouteView::OnUpdateSort(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID == m_nCurrSort);
}

void CRouteView::OnMenuSelect(UINT nID)
{
	CString info;
	info.Format(_T("�˵�%c"),'A'+nID-ID_RMENU_A);
	AfxMessageBox(info);
}

void CRouteView::OnToorBarButton()
{
	AfxMessageBox(_T("add code here"));
}

void CRouteView::OnPaint()
{
	CPaintDC dc(this); // ���ڻ��Ƶ��豸������

	CRect rectTree;
	m_wndRouteView.GetWindowRect(rectTree);
	ScreenToClient(rectTree);

	rectTree.InflateRect(1, 1);
	dc.Draw3dRect(rectTree, ::GetSysColor(COLOR_3DSHADOW), ::GetSysColor(COLOR_3DSHADOW));
}

void CRouteView::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);

	m_wndRouteView.SetFocus();
	//SwitchProp();
}

void CRouteView::OnChangeVisualStyle()
{
	m_RouteViewImages.DeleteImageList();

	UINT uiBmpId = theApp.m_bHiColorIcons ? IDB_ROUTE_VIEW_24 : IDB_ROUTE_VIEW;

	CBitmap bmp;
	if (!bmp.LoadBitmap(uiBmpId))
	{
		TRACE(_T("�޷�����λͼ: %x\n"), uiBmpId);
		ASSERT(FALSE);
		return;
	}

	BITMAP bmpObj;
	bmp.GetBitmap(&bmpObj);

	UINT nFlags = ILC_MASK;

	nFlags |= (theApp.m_bHiColorIcons) ? ILC_COLOR24 : ILC_COLOR4;

	m_RouteViewImages.Create(16, bmpObj.bmHeight, nFlags, 0, 0);
	m_RouteViewImages.Add(&bmp, RGB(255, 0, 0));

	m_wndRouteView.SetImageList(&m_RouteViewImages, TVSIL_NORMAL);

	m_wndToolBar.CleanUpLockedImages();
	m_wndToolBar.LoadBitmap(theApp.m_bHiColorIcons ? IDB_SORT_24 : IDR_SORT, 0, 0, TRUE /* ����*/);
}

//void CRouteView::SwitchProp()
//{
//	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
//	if(pMain)
//	{
//		DEVICE dev;
//		HTREEITEM node=m_wndRouteView.GetSelectedItem();
//		if(node)
//		{
//			DWORD nodeID=m_wndRouteView.GetItemData(node);
//			TRACE("RouteView On Focus with ID %06d\n",nodeID);
//			//
//			if(nodeID!=0xFFFFFFFF)//must check!!!
//			{
//				CEarthQDoc *pDoc = (CEarthQDoc*)pMain->GetDocPtr();//MDIGetActive()->GetActiveView()->GetDocument();
//				if(pDoc&&(pDoc->FindDevByID(nodeID,&dev)))
//				{
//					pMain->m_wndProperties.SwitchProp(TRUE,&dev);//��GroupView�෴
//					return;
//				}
//			}
//		}
//		/*Ĭ��*/
//		pMain->m_wndProperties.SwitchProp(TRUE);
//
//	}
//}
