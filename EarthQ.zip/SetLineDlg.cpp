// SetLineDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "SetLineDlg.h"
#include "afxdialogex.h"

#include "MainFrm.h"


// SetLineDlg �Ի���

IMPLEMENT_DYNAMIC(SetLineDlg, CDialogEx)

SetLineDlg::SetLineDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(SetLineDlg::IDD, pParent)
{

}

SetLineDlg::~SetLineDlg()
{
}

void SetLineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(SetLineDlg, CDialogEx)
	
	ON_BN_CLICKED(IDC_BUTTON1, &SetLineDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_START_COLLECT, &SetLineDlg::OnBnClickedStartCollect)
	ON_BN_CLICKED(IDC_TRANSFER, &SetLineDlg::OnBnClickedTransfer)
	ON_BN_CLICKED(IDC_BUTTON2, &SetLineDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


CEarthQDoc* SetLineDlg:: GetDocPtr(void) // �ǵ��԰汾��������
{
	CEarthQApp * pMyApp = (CEarthQApp *)AfxGetApp();
	POSITION p =pMyApp->GetFirstDocTemplatePosition();
	CEarthQDoc *pDoc=NULL;
	if(p)
	{
		CDocTemplate* pDocTemplate =  pMyApp->GetNextDocTemplate(p);
		//if(pDocTemplate)
		{
			p = pDocTemplate->GetFirstDocPosition();
			if(p)
			{
				pDoc=(CEarthQDoc *)pDocTemplate->GetNextDoc(p);
			}
		}
	}
	return pDoc;
}



// SetLineDlg ��Ϣ��������



//���ӽڵ�WiFi
void SetLineDlg::OnBnClickedButton1()
{
	CEarthQDoc *pDoc = GetDocPtr();
	if(pDoc)
	{
		pDoc->EncodeWifiCanBeOnline_C5(pDoc->coorSocket);

		int m = sizeof(pDoc->msgToSend);

		char msg[14] = {0};
		
		int j = sizeof(msg);

		memcpy(msg,pDoc->msgToSend,sizeof(pDoc->msgToSend));

		int n = sizeof(msg);

		srv.createNewIO2Send(pDoc->coorSocket,pDoc->coorADDR_IN,msg);

	}

}

//��ʼ�ɼ�
void SetLineDlg::OnBnClickedStartCollect()
{
	CEarthQDoc *pDoc = GetDocPtr();
	if(pDoc)
	{
		pDoc->EncodeStartCollectData(pDoc->coorSocket);
		
		srv.createNewIO2Send(pDoc->coorSocket,pDoc->coorADDR_IN,pDoc->msgToSend);
	}
}

//������Դ
void SetLineDlg::OnBnClickedButton2()
{
	CEarthQDoc *pDoc = GetDocPtr();
	if(pDoc)
	{
		if(pDoc->IsBlasterReady)
		{
			pDoc->EncodeBlasterBlast(pDoc->coorSocket);
			
			srv.createNewIO2Send(pDoc->coorSocket,pDoc->coorADDR_IN,pDoc->msgToSend);
			
			//pDoc->IsBlasterReady = FALSE;
		}
		else
		{
			//TODO������Դ���ߴ�ʹ�ܼ��ɣ���ʼΪ��

			//srv._ShowMessage("�ȴ���Դ");
			AfxMessageBox("�ȴ���Դ��Ӧ�����Ժ����ԣ�");
		}
	}
}


//��������
void SetLineDlg::OnBnClickedTransfer()
{
	CEarthQDoc *pDoc = GetDocPtr();
	if(pDoc)
	{
		//��ȡ����ʱ��
		memset(blastTime,0,8);
		for(int i=0;i<8;i++)
		{
			blastTime[i] = pDoc->TotalTime[i];
		}

		pDoc->EncodeBlastTimeGet2coor(pDoc->coorSocket,blastTime);

		srv.createNewIO2Send(pDoc->coorSocket,pDoc->coorADDR_IN,pDoc->msgToSend);
	}
}




