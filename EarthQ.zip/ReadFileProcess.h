#pragma once
#include "afxcmn.h"

class CMainFrame;
// CReadFileProcess �Ի���

class CReadFileProcess : public CDialogEx
{
	DECLARE_DYNAMIC(CReadFileProcess)

public:
	CReadFileProcess(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CReadFileProcess();

// �Ի�������
	enum { IDD = IDD_READFILEPROCESS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	void ShowMyDialog(CMainFrame *pFather);
	void ProcessBarPosCtrl(int devNum,int traceNum);
	virtual BOOL OnInitDialog();

protected:
	CMainFrame *pFatehrFrame;
public:
	CProgressCtrl m_Progress;
	int m_nMax,m_nStep,m_nCurPos;//���ֵ�Ͳ���
	

};
