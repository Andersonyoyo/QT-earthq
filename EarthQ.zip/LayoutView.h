
// LayoutView.h : LayoutView ��Ľӿ�
//

#pragma once

class LayoutView : public CView
{
protected: // �������л�����
	LayoutView();
	DECLARE_DYNCREATE(LayoutView)

// ����
public:
	CEarthQDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// ʵ��
public:
	virtual ~LayoutView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
};

#ifndef _DEBUG  // LayoutView.cpp �еĵ��԰汾
inline CEarthQDoc* LayoutView::GetDocument() const
   { return reinterpret_cast<CEarthQDoc*>(m_pDocument); }
#endif

