#pragma once
#include "resource.h"
#include "afxcmn.h"
#include "DeviceDescribe.h"
//#include "GroupView.h"
#include "ViewTree.h"
#include<vector>
#include "afxwin.h"

class CMainFrame;
class CGroupView;

using namespace std;
// CDrawDataDlg �Ի���

class CDrawDataDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CDrawDataDlg)

public:
	CDrawDataDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDrawDataDlg();

// �Ի�������
	enum { IDD = IDD_DRAWDATADLG };
public:
	
	vector<float> recData;

	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual void OnDraw(CDC *pDC);

public:
		DECLARE_MESSAGE_MAP()
public:

	void getDrawInfo(DEVICE *SelectedDev);

	void DrawWave(CDC *pDC, CRect &rectPicture);
	void FreshLine(CDC *pDc,CRect rectPicture);

	void ShowMyDialog(CMainFrame *pFather);
	
	//CStatic m_picDraw;
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
protected:
	CMainFrame *pFatehrFrame;
public:
	
	int m_traceNum;
	CStatic m_picDraw;
};
