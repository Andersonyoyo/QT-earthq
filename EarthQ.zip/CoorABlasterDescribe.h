#pragma once


typedef enum{
	COOR_ADD=0,
	COOR_FRESH,
	COOR_REMOVE,
}COOR_OPERATE;
#define MAX_COORABLASTER_NUM 50


class CoorABlaster{
public:
	CoorABlaster(){
		IsSelect=FALSE;
		IsSelecting=FALSE;
		devType=0;
	};
	~CoorABlaster(){};	


	CString MAC;
	float Latitude;/*ά��*/
	float Longitude;/*����*/

	BYTE devType;
	BOOL IsSelect;
	BOOL IsSelecting;

	float Posx;
	float Posy;
};