#pragma once
#include "resource.h"
//#include "MainFrm.h"
#include "afxwin.h"
// CSetInfoDlg �Ի���
class CMainFrame;

class CSetInfoDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CSetInfoDlg)

public:
	CSetInfoDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSetInfoDlg();

// �Ի�������
	enum { IDD = IDD_SETINFODLG };

public:
	void ShowMyDialog(CMainFrame *pFather);


protected:
	CMainFrame *pFatehrFrame;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	
	afx_msg void OnBnClickedApply();
	UINT m_traceNum;
	//UINT m_sampleInterval;
	//UINT m_sampleNum;
	//UINT m_samplingRate;

	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();


	afx_msg void OnBnClickedRadioBlaster();
	afx_msg void OnBnClickedRadioArtifacial();
	
	int m_samplingRate;
	float m_sampleCollTime;
	UINT m_blaDepth;
};
