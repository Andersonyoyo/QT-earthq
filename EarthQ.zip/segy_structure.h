void create_Empty_SegY_File(string path, size_t size);
void writeFileText(FIleStream stream, value);
void writeFileHeader(stream, value);
void writeTraceHeader();
void weiteSample(stream,position,value);