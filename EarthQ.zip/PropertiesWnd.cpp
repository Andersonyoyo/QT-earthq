
#include "stdafx.h"

#include "PropertiesWnd.h"
#include "Resource.h"

#include "EarthQ.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// CResourceViewBar

CPropertiesWnd::CPropertiesWnd()
{
}

CPropertiesWnd::~CPropertiesWnd()
{
}

BEGIN_MESSAGE_MAP(CPropertiesWnd, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


int CPropertiesWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	if(!m_setLine.Create(IDD_SETLINES,this))
	{
		TRACE0("fail to create lineDlg\n");
		return -1;
	}

	m_setLine.ShowWindow(SW_SHOW);

	return 0;
}

void CPropertiesWnd::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	m_setLine.SetWindowPos(NULL,-1,-1,cx,cy,SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
}


void CPropertiesWnd::OnDestroy()
{
	CDockablePane::OnDestroy();

	// TODO: �ڴ˴�������Ϣ�����������
	m_setLine.DestroyWindow();
}
