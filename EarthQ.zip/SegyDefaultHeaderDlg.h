#pragma once
#include "afxwin.h"


// CSegyDefaultHeaderDlg �Ի���
class CMainFrame;
class CSegyDefaultHeaderDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CSegyDefaultHeaderDlg)

public:
	CSegyDefaultHeaderDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSegyDefaultHeaderDlg();

// �Ի�������
	enum { IDD = IDD_SEGYDEFAULTHEADERDLG };

protected:
	CMainFrame *pFatehrFrame;
public:
	void ShowMyDialog(CMainFrame *pFather);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox m_sampleCode;
	CComboBox m_gainType;
	CComboBox m_traceSort;
	afx_msg void OnBnClickedApply1();
};
