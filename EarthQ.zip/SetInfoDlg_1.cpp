// SetInfoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "SetInfoDlg.h"
#include "afxdialogex.h"
#include "EarthQDoc.h"
#include "resource.h"

// CSetInfoDlg �Ի���

IMPLEMENT_DYNAMIC(CSetInfoDlg, CDialogEx)

CSetInfoDlg::CSetInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSetInfoDlg::IDD, pParent)
	, m_traceNum(0)
	//, m_sampleInterval(0)
	//, m_sampleNum(0)
	//,m_samplingRate(0)
	, m_samplingRate(0)
	, m_sampleCollTime(0)
	, m_blaDepth(0)
{

}

void CSetInfoDlg::ShowMyDialog(CMainFrame *pFather)
{
	pFatehrFrame = pFather;
	DoModal();
}

CSetInfoDlg::~CSetInfoDlg()
{
}

//������Ϣ
void CSetInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TRACENUM, m_traceNum);
	//DDX_Text(pDX, IDC_SAMPLEINTERVAL, m_sampleInterval);
	//DDX_Text(pDX, IDC_SAMPLINGRATE, /*m_sampleNum*/m_samplingRate);

	DDX_Text(pDX, IDC_SAMPLINGRATE, m_samplingRate);
	DDX_Text(pDX, IDC_SAMPLECOLLTIME, m_sampleCollTime);
	DDX_Text(pDX, IDC_BLADEPTH, m_blaDepth);
}


BEGIN_MESSAGE_MAP(CSetInfoDlg, CDialogEx)
	ON_BN_CLICKED(IDC_APPLY, &CSetInfoDlg::OnBnClickedApply)
	ON_BN_CLICKED(IDOK, &CSetInfoDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSetInfoDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_RADIO_BLASTER, &CSetInfoDlg::OnBnClickedRadioBlaster)
	ON_BN_CLICKED(IDC_RADIO_ARTIFACIAL, &CSetInfoDlg::OnBnClickedRadioArtifacial)
END_MESSAGE_MAP()


// CSetInfoDlg ��Ϣ��������


void CSetInfoDlg::OnBnClickedApply()
{
	UpdateData(TRUE);

	CEarthQApp * pMyApp = (CEarthQApp *)AfxGetApp();
	POSITION p =pMyApp->GetFirstDocTemplatePosition();
	CEarthQDoc *pDoc=NULL;
	if(p)
	{
		CDocTemplate* pDocTemplate =  pMyApp->GetNextDocTemplate(p);
		//if(pDocTemplate)
		{
			p = pDocTemplate->GetFirstDocPosition();
			if(p)
			{
				pDoc=(CEarthQDoc *)pDocTemplate->GetNextDoc(p);
			}
		}
	}

	pDoc->SegYBinHeadCall(m_traceNum,m_sampleCollTime,m_samplingRate,m_blaDepth);

	UpdateData(FALSE);
	CWnd *pWnd = GetDlgItem(IDC_APPLY);
	pWnd->EnableWindow(FALSE);
}


void CSetInfoDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);


	CEarthQApp * pMyApp = (CEarthQApp *)AfxGetApp();
	POSITION p =pMyApp->GetFirstDocTemplatePosition();
	CEarthQDoc *pDoc=NULL;
	if(p)
	{
		CDocTemplate* pDocTemplate =  pMyApp->GetNextDocTemplate(p);
		//if(pDocTemplate)
		{
			p = pDocTemplate->GetFirstDocPosition();
			if(p)
			{
				pDoc=(CEarthQDoc *)pDocTemplate->GetNextDoc(p);
			}
		}
	}

	pDoc->SegYBinHeadCall(m_traceNum,m_sampleCollTime,m_samplingRate,m_blaDepth);

	UpdateData(FALSE);
	CWnd *pWnd = GetDlgItem(IDC_APPLY);
	pWnd->EnableWindow(FALSE);

	CDialogEx::OnOK();
}


void CSetInfoDlg::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnCancel();
}


//ѡ����Դ����
void CSetInfoDlg::OnBnClickedRadioBlaster()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

//ѡ���˹�����
void CSetInfoDlg::OnBnClickedRadioArtifacial()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
