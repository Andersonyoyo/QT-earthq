// MyMFCToolBar.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "MyMFCToolBar.h"


// MyMFCToolBar

IMPLEMENT_DYNAMIC(MyMFCToolBar, CMFCToolBar)

MyMFCToolBar::MyMFCToolBar()
{

}

MyMFCToolBar::~MyMFCToolBar()
{
}


BEGIN_MESSAGE_MAP(MyMFCToolBar, CMFCToolBar)
END_MESSAGE_MAP()



// MyMFCToolBar ��Ϣ��������
BOOL MyMFCToolBar::CanBeClosed() const  
{  
	return FALSE;  
} 

