#pragma once
#include "afxwin.h"


// InfoDisplayDlg �Ի���

class InfoDisplayDlg : public CDialog
{
	DECLARE_DYNAMIC(InfoDisplayDlg)

public:
	InfoDisplayDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~InfoDisplayDlg();

// �Ի�������
	enum { IDD = IDD_INFO_DISPLAY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	void DisplayBlastTime(CString blastTime);

	
	
	CString m_blastMon;
	virtual BOOL OnInitDialog();
};
