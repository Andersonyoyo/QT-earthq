// ReadFileProcess.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "ReadFileProcess.h"
#include "afxdialogex.h"


// CReadFileProcess �Ի���

IMPLEMENT_DYNAMIC(CReadFileProcess, CDialogEx)

CReadFileProcess::CReadFileProcess(CWnd* pParent /*=NULL*/)
	: CDialogEx(CReadFileProcess::IDD, pParent)
{

}

CReadFileProcess::~CReadFileProcess()
{
}

void CReadFileProcess::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_READ_FILE_PROGRESS, m_Progress);
	
}


BEGIN_MESSAGE_MAP(CReadFileProcess, CDialogEx)
	
END_MESSAGE_MAP()


// CReadFileProcess ��Ϣ��������


void CReadFileProcess::ShowMyDialog(CMainFrame *pFather)
{
	pFatehrFrame = pFather;
	DoModal();
}

void CReadFileProcess::ProcessBarPosCtrl(int devNum,int traceNum)
{
	m_nMax = traceNum;
	m_nCurPos = (((float)devNum)/traceNum)*100;
	m_Progress.SetPos(m_nCurPos);


}

BOOL CReadFileProcess::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_Progress.SetRange(0,100);
	m_Progress.SetStep(1);
	m_Progress.SetPos(0);



	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


