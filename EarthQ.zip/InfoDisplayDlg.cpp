// InfoDisplayDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EarthQ.h"
#include "InfoDisplayDlg.h"
#include "afxdialogex.h"


// InfoDisplayDlg �Ի���

IMPLEMENT_DYNAMIC(InfoDisplayDlg, CDialog)

InfoDisplayDlg::InfoDisplayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(InfoDisplayDlg::IDD, pParent)
	, m_blastMon(_T(""))
{

}

InfoDisplayDlg::~InfoDisplayDlg()
{
}

void InfoDisplayDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_BLAST_MON, m_blastMon);
}


BEGIN_MESSAGE_MAP(InfoDisplayDlg, CDialog)
END_MESSAGE_MAP()


// InfoDisplayDlg ��Ϣ��������
BOOL InfoDisplayDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void InfoDisplayDlg::DisplayBlastTime(CString blastTime)
{
	//UpdateData(TRUE);
	m_blastMon = blastTime;
	UpdateData(FALSE);
	//this->SetDlgItemTextA(IDC_BLAST_MON,m_blastMon);
	
}


